/* 
 * File:   menu_bar.c
 * Author: Rahul H H
 *
 * Created on March 7, 2025, 3:43 PM
 */

#include <stdio.h>
#include <stdlib.h>

/*
 * 
 */
int main(int argc, char** argv) {

    return (EXIT_SUCCESS);
}

